package com.acme.customers.lib.v1;

public enum CustomerStatus {
    ACTIVE, INACTIVE
}
