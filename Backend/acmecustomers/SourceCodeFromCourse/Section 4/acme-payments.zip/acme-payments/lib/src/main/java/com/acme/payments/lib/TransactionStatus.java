package com.acme.payments.lib;

public enum TransactionStatus {

    SETTLED,
    DECLINED,
    FAILED;
}
