package com.acme.payments.api.services.exceptions;

public class UnauthorizedException extends RuntimeException {
}
