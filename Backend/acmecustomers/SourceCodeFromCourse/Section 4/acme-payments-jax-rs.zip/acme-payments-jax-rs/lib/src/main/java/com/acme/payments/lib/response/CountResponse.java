package com.acme.payments.lib.response;

public class CountResponse {

    private Long count;

    public Long getCount() {
        return count;
    }

    public void setCount(Long count) {
        this.count = count;
    }
}
