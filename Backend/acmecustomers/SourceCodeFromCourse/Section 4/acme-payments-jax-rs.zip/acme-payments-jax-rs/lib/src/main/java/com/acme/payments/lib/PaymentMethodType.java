package com.acme.payments.lib;

public enum PaymentMethodType {

    CREDIT_CARD,
    PAYPAL,
    APPLE_PAY,
    OTHER;
}
