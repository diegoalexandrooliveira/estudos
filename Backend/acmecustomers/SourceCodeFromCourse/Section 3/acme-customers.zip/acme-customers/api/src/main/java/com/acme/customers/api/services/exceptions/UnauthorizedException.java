package com.acme.customers.api.services.exceptions;

public class UnauthorizedException extends RuntimeException {
}
