package com.acme.orders.lib.v1;

public enum OrderStatus {

    NEW, COMPLETED, CANCELED;
}
