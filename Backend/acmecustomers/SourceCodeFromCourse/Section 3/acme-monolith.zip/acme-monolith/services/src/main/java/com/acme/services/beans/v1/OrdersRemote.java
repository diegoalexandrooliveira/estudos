package com.acme.services.beans.v1;

public interface OrdersRemote extends OrdersLocal {
}
