package com.acme.services.beans.v1;

public interface PaymentsRemote extends PaymentsLocal {
}
