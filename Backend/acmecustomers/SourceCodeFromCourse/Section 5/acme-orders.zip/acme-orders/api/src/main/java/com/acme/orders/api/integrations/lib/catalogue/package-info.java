@javax.xml.bind.annotation.XmlSchema(namespace = "http://acme.com/schemes/ecommerce/v1", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.acme.orders.api.integrations.lib.catalogue;
