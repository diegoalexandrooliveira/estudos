package com.example.ms.orders;

public enum OrderStatus {

    COMPLETED,
    IN_PROGRESS
}
