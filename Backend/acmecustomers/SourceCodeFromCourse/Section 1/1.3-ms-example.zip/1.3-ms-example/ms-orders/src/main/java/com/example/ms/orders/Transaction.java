package com.example.ms.orders;

public class Transaction {

    private TranscationCard cardDetails;

    public TranscationCard getCardDetails() {
        return cardDetails;
    }

    public void setCardDetails(TranscationCard cardDetails) {
        this.cardDetails = cardDetails;
    }
}
