package com.example.ms.customers;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/v1")
public class CustomerApplication extends Application {
}
